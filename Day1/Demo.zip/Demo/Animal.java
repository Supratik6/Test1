//polymorphism
public class Animal {
    public void makeNoise(){
        System.out.println("Animal makes a noise");
    }
}

class Dog extends Animal{
    public void makeNoise(){
        System.out.println("Dog barks");
    }
}
 
class Cat extends Animal{
    public void makeNoise(){
        System.out.println("Cat meows");
    }
}

class Main{
    public static void main(String[] args) {
        Animal myObj = new Animal();
        myObj.makeNoise();
    }
}
