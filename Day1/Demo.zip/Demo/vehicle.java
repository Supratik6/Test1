public class vehicle {   //superclass
    protected String brand;
    public void wheel(){
        System.out.println("Vehicle has either 2 or 4 wheels");
    }

    public vehicle(String brand){
        this.brand = brand;
    }
     
    public void showDetails(){
        System.out.println("Brand: "+brand);
    }

    class car extends vehicle{    //sub class
        public car(String brand){
            super(brand);
        }
        public void showDetails(){
            System.out.println("Brand: "+brand);
        }
        
    }
    public static void main(String[] args) {
        vehicle myObj = new vehicle("Toyota");
        myObj.showDetails();
        myObj.wheel();
    }
}
