//class & objects 
//encapsulation 
public class Main{
  /* int x = 5; //class veriable
    int y = 10;*/  
     private int x,y;
    //default constructor
    Main(){
        System.out.println("Constructor called");
    }
    //parameterized constructor
    Main(int x, int y){
        this.x = x;
        this.y = y;
    }

    // class method
    void myMethod(){
        System.out.println("Hello World from class main");
    }
    void add(){
        System.out.println("The sum of x and y is: "+(x+y));
    }
    public static void main(String[] args) {
        Main myObj = new Main(5,10);
        System.out.println("value of x is:  "+myObj.x);
        System.out.println("value of y is : "+myObj.y);
        myObj.myMethod();
        myObj.add();
    }
} 

//Now create a car class with variable brand, model, year
// pass the values to the constructor and show them using a method 
//show details.


public class Car{
    String brand;
    String model;
    int year;
    Car(String brand, String model, int year){
        this.brand = brand;
        this.model = model;
        this.year = year;
    }
    void showDetails(){
        System.out.println("Brand: "+brand);
        System.out.println("Model: "+model);
        System.out.println("Year: "+year);
    }
    public static void main(String[] args) {
        Car myObj = new Car("Toyota", "Camry", 2022);
        myObj.showDetails();
    }
}
*/

//get and set methods


