/*public class Day1 {
    private String name;
    private int age;

    //getter
    public String getName() {
        return name;
    }
    public int getAge() {
        return age;
    }
    //setter
    public void setName(String name) {
        this.name = name;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public static void main(String[] args) {
        Day1 obj = new Day1();
        obj.setName("John");
        obj.setAge(25);
        System.out.println("Name: " + obj.getName());
        System.out.println("Age: " + obj.getAge());
    }
}
*/


