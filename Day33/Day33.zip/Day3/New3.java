public class New3 extends Thread {
    //thread life cycle
    //new
    //runnable
    //running
    //non runnable
    //non running
    public void run(){
        System.out.println("Thread is running...");
    }
    public static void main(String args[]){
        New3 t1=new New3();
        System.out.println("State : "+t1.getState());//new thread example
        t1.start();

        for(int i=0;i<10;i++){
            System.out.println(i);
            System.out.println("State : "+t1.getState()); //terminated state
        }

        //RUNNING STATE
        System.out.println("State : "+t1.getState());

        for(int i=0;i<10;i++){
            System.out.println(i);
        }

        //TERMINATED STATE
        System.out.println("State : "+t1.getState());
        t1.interrupt();
        System.out.println("State : "+t1.getState());
    }
    
    




}
    