//creating a thread

public class New extends Thread{
    public void run(){
        System.out.println("Thread is running...");

    }
    public static void main(String args[]){
        New t1=new New();
        t1.start();
        New t2=new New();
        t2.start(); 

        //id
        System.out.println("id : "+t1.getId());
        System.out.println("id : "+t2.getId());

        //name
        System.out.println("name : "+t1.getName());
        System.out.println("name : "+t2.getName());

        //priority
        System.out.println("priority 1 : "+t1.getPriority());
        System.out.println("priority 2 : "+t2.getPriority());


        //set priority
        t1.setPriority(10);
        t2.setPriority(5);

        //get priority
        System.out.println("priority 1 : "+t1.getPriority());
        System.out.println("priority 2 : "+t2.getPriority());

        //sleep
        try{
            t1.sleep(5000);
        }
        catch(Exception e){
            System.out.println(e);
        }
        System.out.println("Thread is running...");

        //join
        try{
            t1.join();
        }
        catch(Exception e){
            System.out.println(e);
        }
        System.out.println("Thread is running...");


        //yield
        t1.yield();
        System.out.println("Thread is running after yield...");

        //is alive
        System.out.println("Thread is alive : "+t1.isAlive());

        //interrupt
        t1.interrupt();
        System.out.println("Thread is interrupted : "+t1.isInterrupted());

        //is daemon
        System.out.println("Thread is daemon : "+t1.isDaemon());
        t1.setDaemon(true);
        System.out.println("T1 Thread is daemon : "+t1.isDaemon());
        System.out.println("T2 Thread is daemon : "+t2.isDaemon());

        //main thread
        Thread t3=Thread.currentThread();
        System.out.println("Main thread : "+t3.getName());

        //set name
        t3.setName("Main Thread");
        System.out.println("Main thread : "+t3.getName());

        //get name
        System.out.println("Main thread : "+t3.getName());

        //get priority
        System.out.println("Main thread : "+t3.getPriority());

        

        


        







    }
}