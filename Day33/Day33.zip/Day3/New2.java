public class New2 implements Runnable {
    public void run(){
        System.out.println("Thread is running...");
    }
    public static void main(String args[]){
        New2 t1=new New2();
        Thread t2=new Thread(t1);
        t2.start();

        try{
            t2.sleep(1000);
        }
        catch(Exception e){
            System.out.println(e);
        }
        t2.interrupt();
        System.out.println("Thread is interrupted : "+t2.isInterrupted());

        //join
        try{
            t2.join();
        }
        catch(Exception e){
            System.out.println(e);
        }
        System.out.println("Thread is running...");

        //yield
        t2.yield();
        System.out.println("Thread is running after yield...");

        //is alive
        System.out.println("Thread is alive : "+t2.isAlive());  

    }
}
